int main (void)

{
    int i;
    int z;
    printf("\nMATH GAMES!!!!!\n\n");
    printf("\nGIVE YOUR BRAIN A TRY!\n\n");


    for(i=1; i<z; z=z+1)
    {
        int answer = 0;
        int a = rand() % 12;
        int b = rand() % 12;
        printf("\n%d + %d = ",a ,b);
        scanf("%d", &answer);
        if((a + b) == answer)
        {
            printf("\nCongratulations You are correct!\n");

        }
        else
        {
            printf("\nSorry you were incorrect!\n");

        }

    }



}
